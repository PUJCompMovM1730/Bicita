package com.pujhones.bicita.view;

/**
 * Created by Tefa on 30/10/2017.
 */

public class PolylineObject {
    private String points;
    public PolylineObject(String points) {
        this.points = points;
    }
    public String getPoints() {
        return points;
    }
}