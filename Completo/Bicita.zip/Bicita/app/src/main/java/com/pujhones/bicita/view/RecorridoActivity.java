package com.pujhones.bicita.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.pujhones.bicita.R;

public class RecorridoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recorrido);
    }
}
